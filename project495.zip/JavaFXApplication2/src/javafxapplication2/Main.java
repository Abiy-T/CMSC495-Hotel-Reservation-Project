import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;


public class Main extends Application {

    Stage window;
    Scene scnHome, scnRes, scnEmp, scnSubmit, scnViewRes;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;

        //Button for reservations
        Label labelHome = new Label("Welcome to the Hotel 495! Select an option below:");
        Button btnRes = new Button("Reservations");
        btnRes.setOnAction(e -> window.setScene(scnRes));
        
        //Button for employees
        Button btnEmp = new Button("Employee Login");
        btnEmp.setOnAction(e -> window.setScene(scnEmp));


        //Layout 1 -hompage
        VBox layout1 = new VBox(20);
        layout1.getChildren().addAll(labelHome, btnRes, btnEmp);
        scnHome = new Scene(layout1, 600, 600);


        //layout 2 scene 2 reservations
        Label labelReservations = new Label("Please select your number of nights and how many beds below:");
        
        ComboBox numOfNights = new ComboBox<>();
        numOfNights.getItems().addAll(
                "1 Night Stay",
                "3 Nights Stay",
                "5 Night Special"
        );
        
        numOfNights.setPromptText("Nights");
        
        numOfNights.setOnAction( e -> System.out.println("User selected " + numOfNights.getValue()) );

        
        ComboBox numOfBeds = new ComboBox<>();
        numOfBeds.getItems().addAll(
                "1 bed",
                "2 Beds",
                "Suite"
        );
        
        numOfBeds.setPromptText("Beds");
        
        numOfBeds.setOnAction( e -> System.out.println("User selected " + numOfBeds.getValue()) );
        
        Button btnSubmit = new Button("Submit");
        btnSubmit.setOnAction(e -> storeResults(numOfNights,numOfBeds ));
        btnSubmit.setOnAction(e -> window.setScene(scnSubmit));
        
        Button btnReturnHm1 = new Button("Return Home");
        btnReturnHm1.setOnAction(e -> window.setScene(scnHome));
        
        VBox layout2 = new VBox(20);
        layout2.getChildren().addAll(labelReservations, numOfNights, numOfBeds, btnSubmit, btnReturnHm1);
        scnRes = new Scene(layout2, 600, 300);
        
        
        
         //Button 4
        Label labelEmployee = new Label("Enter Your Employee Credentials below:");
        
        TextField userNmInput = new TextField();
       
        Button btnLogin = new Button("Login");
        btnLogin.setOnAction(e -> isTxt(userNmInput, userNmInput.getText()) );
        btnLogin.setOnAction(e -> window.setScene(scnViewRes));
        
        Button btnReturnHm2 = new Button("Return Home");
        btnReturnHm2.setOnAction(e -> window.setScene(scnHome));

        //Layout 3 employee screen
        VBox layout3 = new VBox(20);
        layout3.getChildren().addAll(labelEmployee, userNmInput, btnLogin, btnReturnHm2);
        scnEmp = new Scene(layout3, 600, 300);
       
        //layout4 results
        
        Label labelResults = new Label("Here are your results as follows: ");
        Label labelNights = new Label ("Your Nights: " + numOfNights);
        Label LabelBeds = new Label("Your Choice of Stay: " + numOfBeds);
        Button btnReturnHm3 = new Button("Return Home");
        btnReturnHm3.setOnAction(e -> window.setScene(scnHome));
        
        VBox layout4 = new VBox(20);
        layout4.getChildren().addAll(labelResults, labelNights, LabelBeds, btnReturnHm3);
        scnSubmit = new Scene(layout4, 600, 300);
        
        //layout5 employee login
        Label labelLogin = new Label("Hello " + userNmInput + ", Welcome!");
        Label labelStored = new Label("Here are the existing reservations: ");
        Button btnReturnHm4 = new Button("Return Home");
        btnReturnHm4.setOnAction(e -> window.setScene(scnHome));
        
        VBox layout5 = new VBox(20);
        layout5.getChildren().addAll(labelLogin, labelStored, btnReturnHm4 );
        scnViewRes = new Scene(layout5, 600, 300);
        
        
        

        //Display scene 1 at first
        window.setScene(scnHome);
        window.setTitle("Hotel 495");
        window.show();
   }
    
    private void storeResults(ComboBox nights, ComboBox beds){
        
        System.out.println(nights.getValue());
        System.out.println(beds.getValue());
    }
  
    private boolean isTxt(TextField input, String str){
            
            System.out.println("User is: " + str);
            return true;
    }        
    

}